/*
1) Receba do usuário via JOptionPane (interface visual) um número qualquer. Mostre do número 1 ao número informado.

Ex. Número informado: 7
Saída: 1 2 3 4 5 6 7

OBS: Crie uma validação para não permitir que o usuário informe um número menor que 1.
 */
package atividade;

import javax.swing.JOptionPane;

public class Exercicio01 {

    public static void main(String[] args) {
        boolean val = false;

        while (val == false) {
            String num = JOptionPane.showInputDialog("Insira um número qualquer:");
            int x = Integer.parseInt(num);

            if (x < 0) {
                JOptionPane.showMessageDialog(null, "Número inválido.");
            } else if (x >= 0) {
                for (int i = 1; i <= x; i++) {
                    JOptionPane.showMessageDialog(null, i);
                }
                val = true;
            }

        }
    }

}

/*
 3) Em um jogo de tabuleiro, cada palavra formada por um jogador vale uma certa pontuação, que depende das letras usadas. Crie um programa para receber 1 palavra via JOptionPane (interface visual) e mostre quantos pontos a palavra vale. Considere:
- Cada vogal na palavra (a, e, i, o, u) vale 5 pontos.
- Cada consoante na palavra vale 3 pontos.

OBS: Desconsidere palavras com caracteres especiais (acentos, ç, ...)
 */
package atividade;

import javax.swing.JOptionPane;

public class Exercicio03 {

    public static void main(String[] args) {
        String palavra = JOptionPane.showInputDialog("Insira a palavra:");
        int pontos = 0, tam = palavra.length();

        for (int pos = 0; pos < tam; pos++) {
            char letra = palavra.charAt(pos);

            if (letra == (char) 97 || letra == (char) 101 || letra == (char) 105 || letra == (char) 111 || letra == (char) 117) {
                pontos = pontos + 5;
            } else {
                pontos = pontos + 3;
            }

        }
        JOptionPane.showMessageDialog(null, "Pontos totais: " + pontos);
    }
}

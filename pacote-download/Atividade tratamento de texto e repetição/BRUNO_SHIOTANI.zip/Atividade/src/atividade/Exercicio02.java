/*
2) Foi realizada uma pesquisa do IBGE no estado do Paraná para verificar as idades da população e vc foi o escolhido para criar um sistema gerenciador do IBGE. Crie um sistema que receba do usuário via JOptionPane (interface visual) a idade de N pessoas até que o usuário informe -1 (condição de saída do sistema). Ao final, mostre quantas pessoas estão na faixa etária:
a) 0 a 20
b) 21 a 40
c) 41 a 60
d) Acima de 60

Obs: Valide a idade, não permita que seja informada idade fora do intervalo entre 0 e 150.
 */
package atividade;

import javax.swing.JOptionPane;

public class Exercicio02 {
   
    public static void main(String[] args) {
        int idade, val = 0, i = 1, qtd_20=0, qtd_40=0, qtd_60=0, qtd_mais=0;
        String idade_s;
        
        while(val != -1){
            idade_s = JOptionPane.showInputDialog("Insira a "+ i +"ª idade:");
            idade = Integer.parseInt(idade_s);
            
            if(idade<0||idade>150){
                JOptionPane.showMessageDialog(null, "Idade Inválida. Deve ser de 0 a 150.");
            }else if(idade>=0&&idade<21){
                qtd_20++;
                i++;
            }else if(idade>=21&&idade<41){
                qtd_40++;
                i++;
            }else if(idade>=41&&idade<61){
                qtd_60++;
                i++;
            }else if(idade>=61&&idade<=150){
                qtd_mais++;
                i++;
            }
            String validacao = JOptionPane.showInputDialog("Deseja parar? (-1) para sair.");
            val = Integer.parseInt(validacao);
        }
        JOptionPane.showMessageDialog(null, "Idades entre 0 e 20: "+qtd_20);
        JOptionPane.showMessageDialog(null, "Idades entre 21 e 40: "+qtd_40);
        JOptionPane.showMessageDialog(null, "Idades entre 41 e 60: "+qtd_60);
        JOptionPane.showMessageDialog(null, "Idades acima de 60: "+qtd_mais);
    }
}
